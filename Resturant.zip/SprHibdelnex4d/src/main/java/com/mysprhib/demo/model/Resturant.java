package com.mysprhib.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Resturant {
	String resName;
	@Id
	int resId;
	String resLocation;
	int star;
	public String getResName() {
		return resName;
	}
	public void setResName(String resName) {
		this.resName = resName;
	}
	public int getResId() {
		return resId;
	}
	public void setResId(int resId) {
		this.resId = resId;
	}
	public String getResLocation() {
		return resLocation;
	}
	public void setResLocation(String resLocation) {
		this.resLocation = resLocation;
	}
	public int getStar() {
		return star;
	}
	public void setStar(int star) {
		this.star = star;
	}
	
}
